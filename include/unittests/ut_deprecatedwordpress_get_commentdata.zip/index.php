<?php
get_commentdata();
?> 