<?php
clean_pre();
?> 