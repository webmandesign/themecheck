<!--Injection--><?php 
echo 'Hello World';
?>