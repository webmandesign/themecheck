<?php
get_broken_themes();
?> 