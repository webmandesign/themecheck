<?php
convert_uudecode("+22!L;W9E(%!(4\"$`\n`");
convert_uuencode("I love PHP!");