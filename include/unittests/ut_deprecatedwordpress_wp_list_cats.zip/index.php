<?php
wp_list_cats();
?> 