<?php
get_themes();
?> 