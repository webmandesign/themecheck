<?php
get_attachment_icon_src();
?> 