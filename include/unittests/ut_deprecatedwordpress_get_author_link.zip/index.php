<?php
get_author_link();
?> 