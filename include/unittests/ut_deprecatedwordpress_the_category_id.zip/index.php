<?php
the_category_id();
?> 