<?php
eval('test1');
eval('test2');