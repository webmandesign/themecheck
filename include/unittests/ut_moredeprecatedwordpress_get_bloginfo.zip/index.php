<?php
get_bloginfo('home');
?> 