<?php
comments_rss_link();
?> 