<?php
sanitize_user_object();
?> 