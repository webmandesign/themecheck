<?php
unregister_sidebar_widget();
?> 