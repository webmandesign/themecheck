<!-- Google search api. Since the URL can be created in many different ways, more tests cases (many) should be created  -->
<script>
(function() {
  var gcse = document.createElement('script'); gcse.type = 'text/javascript'; gcse.async = true;
  gcse.src = (document.location.protocol == 'https' ? 'https:' : 'http:') +
      '//www.google.com/cse/cse.js?cx=123456789012345678901:abcdefghij';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(gcse, s);
})();
</script>
<?php