<?php
media_upload_audio();
?> 