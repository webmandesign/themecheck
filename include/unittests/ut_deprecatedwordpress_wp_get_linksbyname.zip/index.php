<?php
wp_get_linksbyname();
?> 