<?php
echo get_bloginfo("stylesheet_directory");
?> 