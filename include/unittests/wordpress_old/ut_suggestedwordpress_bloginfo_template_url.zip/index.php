<?php
bloginfo("template_url");
?> 