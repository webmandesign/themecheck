<?php
echo get_bloginfo("wpurl");
?> 