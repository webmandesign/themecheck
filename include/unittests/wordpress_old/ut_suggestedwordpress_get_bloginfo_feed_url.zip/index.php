<?php
echo get_bloginfo("feed_url");
?> 