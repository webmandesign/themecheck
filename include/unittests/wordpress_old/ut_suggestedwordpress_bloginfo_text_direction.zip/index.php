<?php
bloginfo("text_direction");
?> 