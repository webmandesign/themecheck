<?php
bloginfo("stylesheet_directory");
?> 