<?php
bloginfo("template_directory");
?> 