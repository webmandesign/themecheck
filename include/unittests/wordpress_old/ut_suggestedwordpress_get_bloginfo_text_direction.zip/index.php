<?php
echo get_bloginfo("text_direction");
?> 