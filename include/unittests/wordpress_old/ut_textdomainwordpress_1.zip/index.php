<?php

echo _e( 'Import / Export' );

?>