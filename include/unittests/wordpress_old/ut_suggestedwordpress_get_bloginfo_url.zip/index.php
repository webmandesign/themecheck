<?php
echo get_bloginfo("url");
?> 