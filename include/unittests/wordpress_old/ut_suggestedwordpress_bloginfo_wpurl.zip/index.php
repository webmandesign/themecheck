<?php
bloginfo("wpurl");
?> 