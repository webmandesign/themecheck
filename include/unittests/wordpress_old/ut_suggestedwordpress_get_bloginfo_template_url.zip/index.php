<?php
echo get_bloginfo("template_url");
?> 