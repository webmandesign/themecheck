<?php
bloginfo("url");
?> 