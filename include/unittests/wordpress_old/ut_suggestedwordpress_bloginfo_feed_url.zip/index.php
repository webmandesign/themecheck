<?php
bloginfo("feed_url");
?> 