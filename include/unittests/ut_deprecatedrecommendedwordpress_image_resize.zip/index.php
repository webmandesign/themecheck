<?php
image_resize();
?> 