<?php
$hello = 'Hello World';
$domain = 'domain';
echo _('Hello World', 'domain');
echo _('Hello World', $domain);
echo _($hello, $domain);
?> 