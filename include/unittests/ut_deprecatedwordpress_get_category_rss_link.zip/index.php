<?php
get_category_rss_link();
?> 