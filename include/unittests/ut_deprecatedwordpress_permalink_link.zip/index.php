<?php
permalink_link();
?> 