<?php
wp_print_editor_js();
?> 