<?php
get_attachment_innerhtml();
?> 