<?php
get_linksbyname();
?> 