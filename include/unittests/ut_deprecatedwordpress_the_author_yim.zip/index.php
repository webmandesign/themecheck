<?php
the_author_yim();
?> 