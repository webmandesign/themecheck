<?php
add_option_update_handler();
?> 