<?php
bloginfo('home');
?> 