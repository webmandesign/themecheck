<?php
require($pathfile.$filename);
require_once($pathfile.$filename);
include($pathfile.$filename);
include_once($pathfile.$filename);
?> 