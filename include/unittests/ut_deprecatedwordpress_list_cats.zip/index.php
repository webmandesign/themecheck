<?php
list_cats();
?> 