<?php
get_autotoggle();
?> 