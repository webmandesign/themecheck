<?php
wp_load_image();
?> 