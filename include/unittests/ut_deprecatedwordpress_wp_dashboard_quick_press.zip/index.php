<?php
wp_dashboard_quick_press();
?> 