<?php
include( TEMPLATEPATH . '/searchform.php' );
?> 