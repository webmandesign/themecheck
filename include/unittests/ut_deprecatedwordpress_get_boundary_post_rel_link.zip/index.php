<?php
get_boundary_post_rel_link();
?> 