<?php
get_users_of_blog();
?> 