<?php
get_linkrating();
?> 