<?php
automatic_feed_links();
?> 