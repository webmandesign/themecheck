<?php
remove_custom_background();
?> 