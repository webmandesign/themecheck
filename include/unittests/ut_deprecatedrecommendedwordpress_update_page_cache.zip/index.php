<?php
update_page_cache();
?> 