<?php
get_settings();
?> 