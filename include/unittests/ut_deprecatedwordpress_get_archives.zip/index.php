<?php
get_archives();
?> 