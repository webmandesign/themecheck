<?php
user_can_set_post_date();
?> 