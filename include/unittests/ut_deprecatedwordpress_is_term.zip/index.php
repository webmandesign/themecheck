<?php
is_term();
?> 