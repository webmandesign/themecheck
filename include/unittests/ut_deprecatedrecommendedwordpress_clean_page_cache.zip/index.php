<?php
clean_page_cache();
?> 