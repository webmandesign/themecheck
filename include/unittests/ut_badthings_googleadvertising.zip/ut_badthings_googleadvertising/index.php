<!-- Google adsense api detection. Can be created in many different ways, more tests cases (many) should be created  -->

<script type="text/javascript"><!--
google_ad_client = "pub-7943101569367020";
google_ad_slot = "3075566845";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php