<?php
index_rel_link();
?> 