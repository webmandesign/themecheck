<?php
get_theme();
?> 