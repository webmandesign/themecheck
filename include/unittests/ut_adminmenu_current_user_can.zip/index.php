<?php
current_user_can("level_0");
?>