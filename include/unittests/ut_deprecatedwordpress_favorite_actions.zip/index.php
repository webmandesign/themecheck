<?php
favorite_actions();
?> 