<?php
 //See more at: http://justcoded.com/blog/gumblar-family-virus-removal-tool/#sthash.xtETufBz.dpuf
?>
<script>/*GNU GPL*/ try{window.onload = function(){var X08yhffhg7xkxf = 'injection';document.body.appendChild(X08yhffhg7xkxf);}} catch(e) {}</script>