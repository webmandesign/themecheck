<?php
the_author_email();
?> 