<?php
remove_option_update_handler();
?> 