 <?
$_COOKIE['yahg'];
 ?>