<?php
wp_quicktags();
?> 