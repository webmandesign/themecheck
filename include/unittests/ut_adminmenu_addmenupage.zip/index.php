<?php
add_admin_page('truc', 'truc', "level_9");
?>