<?php
the_author_firstname();
?> 