<?php
user_can_create_post();
?> 