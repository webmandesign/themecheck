<?php
the_author_ID();
?> 