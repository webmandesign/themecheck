<?php
user_can_edit_user();
?> 