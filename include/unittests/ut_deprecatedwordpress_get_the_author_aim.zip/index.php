<?php
get_author_name();
?> 