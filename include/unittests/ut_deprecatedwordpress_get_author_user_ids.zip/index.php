<?php
get_author_user_ids();
?> 