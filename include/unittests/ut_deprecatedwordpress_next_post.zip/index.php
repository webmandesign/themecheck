<?php
next_post();
?> 