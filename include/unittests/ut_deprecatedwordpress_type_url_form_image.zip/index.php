<?php
type_url_form_image();
?> 