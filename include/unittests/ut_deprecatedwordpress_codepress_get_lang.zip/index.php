<?php
codepress_get_lang();
?> 