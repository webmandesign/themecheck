<?php
is_blog_user();
?> 