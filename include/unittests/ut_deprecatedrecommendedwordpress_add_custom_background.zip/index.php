<?php
add_custom_background();
?> 