<?php
user_pass_ok();
?> 