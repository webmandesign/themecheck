<?php
__ngettext_noop();
?> 