<?php
previous_post();
?> 