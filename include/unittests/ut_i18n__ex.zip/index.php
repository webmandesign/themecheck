<?php
$hello = 'Hello World';
$context = 'context';
$domain = 'domain';
echo _ex('Hello World', 'context', 'domain');
echo _ex('Hello World', $context, $domain);
echo _ex($hello, $context, $domain);
?> 