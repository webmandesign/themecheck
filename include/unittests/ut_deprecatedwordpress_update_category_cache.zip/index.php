<?php
update_category_cache();
?> 