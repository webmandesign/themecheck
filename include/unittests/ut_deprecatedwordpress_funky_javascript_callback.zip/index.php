<?php
funky_javascript_callback();
?> 