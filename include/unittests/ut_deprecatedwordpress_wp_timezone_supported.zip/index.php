<?php
wp_timezone_supported();
?> 