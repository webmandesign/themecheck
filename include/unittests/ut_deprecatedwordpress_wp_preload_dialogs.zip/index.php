<?php
wp_preload_dialogs();
?> 