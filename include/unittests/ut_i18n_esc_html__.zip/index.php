<?php
$hello = 'Hello World';
$context = 'context';
$domain = 'domain';
echo esc_html__('Hello World', 'domain');
echo esc_html__('Hello World', $domain);
echo esc_html__($hello, $domain);
?> 