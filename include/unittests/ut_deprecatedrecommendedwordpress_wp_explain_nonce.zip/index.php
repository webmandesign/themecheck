<?php
wp_explain_nonce();
?> 