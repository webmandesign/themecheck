<?php
get_category_children();
?> 