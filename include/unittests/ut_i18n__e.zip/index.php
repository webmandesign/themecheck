<?php
$hello = 'Hello World';
echo _e($hello);
?> 