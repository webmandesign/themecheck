<?php
get_allowed_themes();
?> 