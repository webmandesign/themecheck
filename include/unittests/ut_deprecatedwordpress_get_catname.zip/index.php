<?php
get_catname();
?> 