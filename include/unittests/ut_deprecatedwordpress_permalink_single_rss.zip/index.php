<?php
permalink_single_rss();
?> 