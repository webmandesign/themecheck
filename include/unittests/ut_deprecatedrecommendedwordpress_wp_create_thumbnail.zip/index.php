<?php
wp_create_thumbnail();
?> 