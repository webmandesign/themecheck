<?php
the_category_head();
?> 