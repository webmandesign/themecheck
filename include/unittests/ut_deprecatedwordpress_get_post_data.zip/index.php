<?php
get_post_data();
?> 