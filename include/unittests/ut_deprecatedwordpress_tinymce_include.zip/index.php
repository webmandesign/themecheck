<?php
tinymce_include();
?> 