<?php
get_current_theme();
?> 