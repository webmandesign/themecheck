<?php
the_author_url();
?> 