<?php
current_theme_info();
?> 