<?php
the_post_thumbnail();
?> 