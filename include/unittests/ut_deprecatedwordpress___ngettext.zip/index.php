<?php
__ngettext();
?> 