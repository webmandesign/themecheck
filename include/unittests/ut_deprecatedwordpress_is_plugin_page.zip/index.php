<?php
is_plugin_page();
?> 