<?php
debug_fclose();
?> 