<?php
str_rot13('test');