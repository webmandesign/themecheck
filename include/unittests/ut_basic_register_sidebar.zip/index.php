<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="utf-8">
<?php
    wp_head();
?>
</head>
<body <?php body_class(); ?>>

	<ul id="sidebar">
		<?php dynamic_sidebar( 'right-sidebar' ); ?>
		<?php  ?>
	</ul>
	
	<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
<?php
	add_theme_support( 'automatic-feed-links' );

	comments_template( '/short-comments.php' );
?> 

<?php comment_form( $args, $post_id ); ?> 

<div class="commentlist"><?php wp_list_comments(array('style' => 'div')); ?></div>

<?php wp_link_pages(); ?>

<?php
    wp_footer();
?>

</body>
</html>