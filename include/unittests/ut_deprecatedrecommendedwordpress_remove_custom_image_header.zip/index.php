<?php
remove_custom_image_header();
?> 