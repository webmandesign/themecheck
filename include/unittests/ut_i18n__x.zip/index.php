<?php
$hello = 'Hello World';
$context = 'context';
$domain = 'domain';
echo _x('Hello World', 'context', 'domain');
echo _x('Hello World', $context, $domain);
echo _x($hello, $context, $domain);
?> 