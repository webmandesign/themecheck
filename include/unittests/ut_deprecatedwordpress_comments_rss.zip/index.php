<?php
comments_rss();
?> 