<?php
wp_get_post_cats();
?> 