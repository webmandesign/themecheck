<?php
wp_get_links();
?> 