<?php
start_post_rel_link();
?> 