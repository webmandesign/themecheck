<?php
$hello = 'Hello World';
$context = 'context';
$domain = 'domain';
echo esc_attr_x('Hello World', 'context', 'domain');
echo esc_attr_x('Hello World', $context, $domain);
echo esc_attr_x($hello, $context, $domain);
?> 