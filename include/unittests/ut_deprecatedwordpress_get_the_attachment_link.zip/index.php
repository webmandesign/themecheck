<?php
get_the_attachment_link();
?> 