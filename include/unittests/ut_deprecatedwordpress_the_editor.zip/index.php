<?php
the_editor();
?> 