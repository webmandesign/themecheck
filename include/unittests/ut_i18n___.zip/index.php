<?php
$hello = 'Hello World';
echo __($hello);
?> 