<?php
get_others_drafts();
?> 