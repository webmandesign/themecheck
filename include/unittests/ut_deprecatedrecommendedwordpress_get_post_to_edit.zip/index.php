<?php
get_post_to_edit();
?> 