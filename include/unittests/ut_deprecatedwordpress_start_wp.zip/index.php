<?php
start_wp();
?> 