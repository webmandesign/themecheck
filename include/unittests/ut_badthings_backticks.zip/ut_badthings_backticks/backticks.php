<?php
echo `ls -lart`; // backticks 