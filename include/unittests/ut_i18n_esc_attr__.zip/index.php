<?php
$hello = 'Hello World';
$context = 'context';
$domain = 'domain';
echo esc_attr__('Hello World', 'domain');
echo esc_attr__('Hello World', $domain);
echo esc_attr__($hello, $domain);
?> 