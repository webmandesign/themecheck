<?php
delete_usermeta();
?> 