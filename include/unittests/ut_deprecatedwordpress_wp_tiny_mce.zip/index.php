<?php
wp_tiny_mce();
?> 