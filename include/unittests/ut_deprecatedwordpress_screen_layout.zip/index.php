<?php
screen_layout();
?> 