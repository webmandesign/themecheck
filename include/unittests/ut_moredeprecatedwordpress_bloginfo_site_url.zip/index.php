<?php
bloginfo('site_url');
?> 