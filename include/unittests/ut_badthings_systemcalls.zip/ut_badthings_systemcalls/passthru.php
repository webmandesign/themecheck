<?php
passthru("cat myfile.zip",$err);

