<?php
echo shell_exec('ls -lart');