<?php
echo exec('whoami');