<?php

$descriptorspec = array(
	 0 => array("pipe", "r"),
	 1 => array("pipe", "w"),
	 2 => array("file", "/tmp/error-output.txt", "a") 
);
$cwd = '/tmp';
$env = array('some_option' => 'aeiou');
$process = proc_open('php', $descriptorspec, $pipes, $cwd, $env);
