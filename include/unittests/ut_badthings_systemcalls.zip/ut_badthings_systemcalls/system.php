<?php
$last_line = system('ls', $retval);
