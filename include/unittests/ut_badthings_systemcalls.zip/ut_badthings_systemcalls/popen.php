<?php
popen("/bin/ls","r");