<?php
gzip_compression();
?> 