<?php
debug_fwrite();
?> 