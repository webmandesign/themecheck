<?php
user_can_edit_post_comments();
?> 