<?php
the_author_aim();
?> 