<?php
the_author_icq();
?> 