<?php
define('wp_class_support',true); 
?>