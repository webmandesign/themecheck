<?php
wp_get_single_post();
?> 