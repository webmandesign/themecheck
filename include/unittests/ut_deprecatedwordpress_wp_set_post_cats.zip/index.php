<?php
wp_set_post_cats();
?> 