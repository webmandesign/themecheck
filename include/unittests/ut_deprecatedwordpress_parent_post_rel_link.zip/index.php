<?php
parent_post_rel_link();
?> 