<?php
get_linkobjectsbyname();
?> 