<?php
get_linkcatname();
?> 