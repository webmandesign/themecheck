<?php
get_attachment_icon();
?> 