<?php
wp_dropdown_cats();
?> 