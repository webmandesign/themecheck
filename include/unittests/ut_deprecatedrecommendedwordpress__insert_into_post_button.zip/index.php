<?php
_insert_into_post_button();
?> 