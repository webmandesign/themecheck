<?php
add_custom_image_header();
?> 