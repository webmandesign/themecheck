<?php
the_content_rss();
?> 