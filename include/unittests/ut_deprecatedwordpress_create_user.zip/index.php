<?php
create_user();
?> 