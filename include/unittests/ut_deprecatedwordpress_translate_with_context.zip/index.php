<?php
translate_with_context();
?> 