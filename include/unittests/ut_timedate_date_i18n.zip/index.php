<?php
echo date_i18n('Y m d');
?> 