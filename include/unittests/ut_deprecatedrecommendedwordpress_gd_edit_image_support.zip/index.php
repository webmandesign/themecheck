<?php
gd_edit_image_support();
?> 