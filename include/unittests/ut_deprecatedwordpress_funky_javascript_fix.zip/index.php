<?php
funky_javascript_fix();
?> 