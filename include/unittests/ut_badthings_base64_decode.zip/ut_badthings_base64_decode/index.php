<?php
base64_decode('VGhpcyBpcyBhbiBlbmNvZGVkIHN0cmluZw==');