<?php
clean_url();
?> 