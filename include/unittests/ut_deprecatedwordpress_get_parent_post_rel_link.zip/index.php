<?php
get_parent_post_rel_link();
?> 