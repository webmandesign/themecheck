<?php
$hello = 'Hello World';
$context = 'context';
$domain = 'domain';
echo esc_html_e('Hello World', 'domain');
echo esc_html_e('Hello World', $domain);
echo esc_html_e($hello, $domain);
?> 