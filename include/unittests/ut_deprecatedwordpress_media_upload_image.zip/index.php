<?php
media_upload_image();
?> 