<?php
add_contextual_help();
?> 