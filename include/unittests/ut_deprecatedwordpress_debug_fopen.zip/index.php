<?php
debug_fopen();
?> 