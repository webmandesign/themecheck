<?php
the_author_description();
?> 