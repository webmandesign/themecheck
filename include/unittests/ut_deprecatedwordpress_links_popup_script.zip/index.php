<?php
links_popup_script();
?> 