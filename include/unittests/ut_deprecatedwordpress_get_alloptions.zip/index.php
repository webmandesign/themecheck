<?php
get_alloptions();
?> 