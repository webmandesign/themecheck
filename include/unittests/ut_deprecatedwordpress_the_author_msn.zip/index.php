<?php
the_author_msn();
?> 