<?php
wp_admin_bar_dashboard_view_site_menu();
?> 