<?php
unregister_widget_control();
?> 