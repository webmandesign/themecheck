<?php
file_get_contents($file);
curl_exec('');
?>