<?php
user_can_delete_post();
?> 