<?php
add_admin_page();