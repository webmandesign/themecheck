<?php
get_theme_data();
?> 