<?php
the_author_nickname();
?> 