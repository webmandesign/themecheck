<?php
art_normalize_widget_style_tokens
art_include_lib;
_remove_last_slash($url) {
adi_normalize_widget_style_tokens
m_normalize_widget_style_tokens
bw = '<!--- BEGIN Widget --->';
ew = '<!-- end_widget -->';
end_widget' => '<!-- end_widget -->'
?> 