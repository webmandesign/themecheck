<?php
get_author_rss_link();
?> 