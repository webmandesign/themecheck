<?php
user_can_create_draft();
?> 