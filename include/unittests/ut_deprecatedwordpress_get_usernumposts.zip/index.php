<?php
get_usernumposts();
?> 