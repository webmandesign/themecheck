<?php
register_widget_control();
?> 