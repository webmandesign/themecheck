<?php
get_index_rel_link();
?> 