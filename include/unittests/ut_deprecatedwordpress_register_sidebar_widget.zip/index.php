<?php
register_sidebar_widget();
?> 