<?php
wp_specialchars();
?> 