<?php
base64_encode('This is an encoded string');