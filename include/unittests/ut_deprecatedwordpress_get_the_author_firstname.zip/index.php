<?php
get_the_author_firstname();
?> 