<?php
$hello = 'Hello World';
$domain = 'domain';
echo gettext('Hello World', 'domain');
echo gettext('Hello World', $domain);
echo gettext($hello, $domain);
?> 