<?php
wp_shrink_dimensions();
?> 