<?php
_get_post_ancestors();
?> 