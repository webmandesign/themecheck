<?php
js_escape();
?> 