<?php
is_taxonomy();
?> 