<?php
get_default_page_to_edit();
?> 