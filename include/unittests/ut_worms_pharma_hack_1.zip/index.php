< ? php $XZKsyG='as';
?>