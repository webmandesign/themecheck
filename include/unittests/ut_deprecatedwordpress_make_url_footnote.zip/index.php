<?php
make_url_footnote();
?> 