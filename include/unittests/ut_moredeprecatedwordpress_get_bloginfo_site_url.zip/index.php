<?php
get_bloginfo('site_url');
?> 