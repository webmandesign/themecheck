<?php
$hello = 'Hello World';
$context = 'context';
$domain = 'domain';
echo esc_attr_e('Hello World', 'domain');
echo esc_attr_e('Hello World', $domain);
echo esc_attr_e($hello, $domain);
?> 