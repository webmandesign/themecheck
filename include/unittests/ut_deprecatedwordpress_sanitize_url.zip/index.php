<?php
sanitize_url();
?> 